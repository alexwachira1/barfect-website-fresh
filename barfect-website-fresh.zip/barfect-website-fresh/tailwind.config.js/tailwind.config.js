/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        charcoal: "#1A1A1A",
        "warm-sand": "#F5E9D9",
        terracotta: "#C76B4F",
        "terracotta-dark": "#B05A3F",
        "savanna-beige": "#E8DCC7",
        "solar-gold": "#F8C74A",
        "hydro-teal": "#3ABEB5",
        "forest-regen": "#4ADE80",
        "diaspora-purple": "#8B5CF6",
        sand: "#F5E9D9",
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],      // ← Default font
        caveat: ['Caveat', 'cursive'],      // ← For quotes
      },
    },
  },
  plugins: [],
};
