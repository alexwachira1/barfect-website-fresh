import Hero from "./components/Hero";
import WhatWeBuild from "./components/WhatWeBuild";
import LegacyCTA from "./components/LegacyCTA";

function App() {
  return (
    <div className="font-sans">
      <Hero />
      <WhatWeBuild />
      <LegacyCTA />
    </div>
  );
}

export default App;